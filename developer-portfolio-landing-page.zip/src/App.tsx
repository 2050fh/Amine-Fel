import Nav from "./components/Nav";
import Hero from "./components/Hero";
import About from "./components/About";
import Experience from "./components/Experience";
import CaseStudies from "./components/CaseStudies";
import Lab from "./components/Lab";
import Skills from "./components/Skills";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="bg-bg text-text">
      <Nav />
      <main>
        <Hero />
        <About />
        <Experience />
        <CaseStudies />
        <Lab />
        <Skills />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
