export type CaseStudy = {
  sector: string;
  title: string;
  result: string;
  stack: string[];
  status: "Delivered" | "In progress";
};

export const CASE_STUDIES: CaseStudy[] = [
  {
    sector: "SaaS · Customer Support",
    title: "AI Ticket Triage & Reply Assistant",
    result:
      "Built a Python + LLM pipeline that auto-classifies and drafts responses to support tickets — cutting manual handling time by ~15 hours per week.",
    stack: ["Python", "FastAPI", "OpenAI API"],
    status: "Delivered",
  },
  {
    sector: "Retail · E-commerce",
    title: "Storefront Performance Rebuild",
    result:
      "Rebuilt a slow legacy storefront into a fast, responsive React interface — improving load speed 3x and lifting mobile conversion rate.",
    stack: ["React", "Vite", "Tailwind CSS"],
    status: "Delivered",
  },
  {
    sector: "Logistics · Internal Tooling",
    title: "Real-Time Operations Dashboard",
    result:
      "Replaced a stack of manually-updated spreadsheets with a single live dashboard, removing a full day of manual reporting each week.",
    stack: ["Node.js", "MongoDB", "React"],
    status: "Delivered",
  },
  {
    sector: "Marketing Agency",
    title: "Custom AI Content Assistant",
    result:
      "Shipped a GPT-powered writing assistant embedded in the client's workflow, roughly tripling content output without new hires.",
    stack: ["Python", "Flask", "OpenAI API"],
    status: "Delivered",
  },
  {
    sector: "Startup · Mobile MVP",
    title: "Cross-Platform Booking App",
    result:
      "Designed and shipped a Flutter MVP backed by a Node.js API in six weeks, used to validate the product with early users.",
    stack: ["Flutter", "Node.js", "MongoDB"],
    status: "Delivered",
  },
  {
    sector: "Service Business",
    title: "Automated Scheduling System",
    result:
      "Built a booking system with calendar sync and SMS reminders, eliminating manual phone scheduling and no-shows.",
    stack: ["JavaScript", "Node.js", "Twilio API"],
    status: "In progress",
  },
];
