export type LabProject = {
  name: string;
  tagline: string;
  desc: string;
  stack: string[];
  repo: string;
  demo?: string;
};

export const LAB_PROJECTS: LabProject[] = [
  {
    name: "NoteMind",
    tagline: "AI note-taking & summarization app",
    desc: "A personal AI-powered notebook that transcribes, summarizes and tags notes in real time using an LLM pipeline. Built to explore retrieval-augmented search over personal knowledge.",
    stack: ["React", "Node.js", "MongoDB", "OpenAI API"],
    repo: "https://github.com/aminefellah/notemind",
    demo: "https://notemind.vercel.app",
  },
  {
    name: "PulseBoard",
    tagline: "Real-time analytics dashboard kit",
    desc: "An open-source dashboard template with live data streaming, built to demonstrate clean component architecture and WebSocket-driven UI updates.",
    stack: ["React", "Vite", "Tailwind CSS", "Node.js"],
    repo: "https://github.com/aminefellah/pulseboard",
    demo: "https://pulseboard.vercel.app",
  },
  {
    name: "PyFlow Automate",
    tagline: "Python task automation toolkit",
    desc: "A lightweight CLI toolkit for scheduling scrapers, data pipelines and repetitive workflows — the same patterns used in client automation projects.",
    stack: ["Python", "Flask", "Cron"],
    repo: "https://github.com/aminefellah/pyflow-automate",
  },
];
