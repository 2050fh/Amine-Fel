export const SOCIAL = {
  email: "fellah.amine2050@gmail.com",
  phone: "0562664409",
  phoneHref: "tel:+213562664409",
  instagram: "https://instagram.com/2050_fh",
  github: "https://github.com/aminefellah",
  linkedin: "https://www.linkedin.com/in/amine-fellah-dev",
};
