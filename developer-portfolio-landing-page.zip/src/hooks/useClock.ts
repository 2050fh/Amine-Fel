import { useEffect, useState } from "react";

/** Returns a live HH:MM:SS string for GMT+1 (Algeria time). */
export function useClock() {
  const [time, setTime] = useState("--:--:--");

  useEffect(() => {
    const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
    const tick = () => {
      const now = new Date();
      const utc = now.getTime() + now.getTimezoneOffset() * 60000;
      const t = new Date(utc + 3600000);
      setTime(`${pad(t.getHours())}:${pad(t.getMinutes())}:${pad(t.getSeconds())}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  return time;
}
