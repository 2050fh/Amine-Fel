import Reveal from "./Reveal";
import SectionHead from "./SectionHead";

const FACTS = [
  { k: "Based in", v: "El Tarf, Algeria" },
  { k: "University", v: "Chadli Bendjedid Univ. (Science & Tech.)" },
  { k: "Focus", v: "AI Systems · Full-Stack · Automation" },
  { k: "Engagement", v: "Remote-first, worldwide clients" },
  { k: "Status", v: "Available for freelance" },
];

export default function About() {
  return (
    <section id="about" className="py-[110px]">
      <div className="mx-auto w-full max-w-[1140px] px-6">
        <SectionHead eyebrow="About">
          A developer who thinks in <em className="text-accent not-italic italic">systems</em> —
          and ships like one.
        </SectionHead>

        <div className="grid grid-cols-1 items-start gap-10 md:grid-cols-[1.4fr_1fr] md:gap-[60px]">
          <Reveal>
            <p className="mb-6 font-serif text-[clamp(1.3rem,3vw,1.7rem)] font-light leading-[1.4] text-text">
              I'm Amine — a freelance AI &amp; full-stack developer building
              practical, production-grade software with AI, JavaScript and
              Python.
            </p>
            <div className="max-w-[560px] space-y-[18px] text-muted">
              <p>
                I study Science &amp; Technology at Chadli Bendjedid
                University of El Tarf, and spend the rest of my time turning
                client ideas into working products — from AI-driven
                automations to clean, responsive web applications.
              </p>
              <p>
                I work in short, focused iterations: scope the problem, ship
                a working version fast, then refine. Every engagement is
                treated like a real product, not a one-off script — with
                clean code, sensible architecture and clear communication
                throughout.
              </p>
              <p>
                Outside of code, I'm a chess player, photographer and artist,
                and I train in kickboxing, running and lifting. The same
                discipline I bring to sport is what I bring to every line of
                code: focus, patience and the drive to keep improving.
              </p>
            </div>
          </Reveal>

          <Reveal className="border-t border-line" delay={100}>
            {FACTS.map((f) => (
              <div
                key={f.k}
                className="flex items-center justify-between gap-4 border-b border-line py-4"
              >
                <span className="text-[0.82rem] uppercase tracking-wider text-faint">
                  {f.k}
                </span>
                <span className="text-right text-[0.92rem] text-text">
                  {f.v}
                </span>
              </div>
            ))}
          </Reveal>
        </div>
      </div>
    </section>
  );
}
