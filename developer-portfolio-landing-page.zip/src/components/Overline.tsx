export default function Overline({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2.5 text-[0.72rem] font-medium uppercase tracking-[0.22em] text-faint before:block before:h-px before:w-[22px] before:bg-accent">
      {children}
    </span>
  );
}
