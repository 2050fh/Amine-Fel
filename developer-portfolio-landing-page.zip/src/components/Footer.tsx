import { useClock } from "../hooks/useClock";
import { SOCIAL } from "../data/links";

const DIRECTORY = [
  { href: "#about", label: "About" },
  { href: "#experience", label: "Experience" },
  { href: "#work", label: "Case Studies" },
  { href: "#lab", label: "Lab" },
  { href: "#skills", label: "Stack" },
  { href: "#contact", label: "Contact" },
];

export default function Footer() {
  const time = useClock();

  return (
    <footer className="border-t border-line py-14 pb-10">
      <div className="mx-auto w-full max-w-[1140px] px-6">
        <div className="mb-11 grid grid-cols-1 gap-10 sm:grid-cols-3">
          <div>
            <div className="mb-3.5 font-serif text-[1.4rem]">
              Amine Fellah<span className="text-accent">.</span>
            </div>
            <p className="max-w-[320px] text-[0.9rem] text-muted">
              AI &amp; Full-Stack Developer — freelance, based in El Tarf,
              Algeria. Building with AI, JavaScript, Python and modern web
              tooling.
            </p>
          </div>
          <div>
            <h5 className="mb-4 text-[0.72rem] uppercase tracking-[0.18em] text-faint">
              Directory
            </h5>
            {DIRECTORY.map((d) => (
              <a
                key={d.href}
                href={d.href}
                className="mb-2.5 block text-[0.9rem] text-muted transition-colors duration-300 hover:text-accent"
              >
                {d.label}
              </a>
            ))}
          </div>
          <div>
            <h5 className="mb-4 text-[0.72rem] uppercase tracking-[0.18em] text-faint">
              Connect
            </h5>
            <a
              href={SOCIAL.github}
              target="_blank"
              rel="noopener noreferrer"
              className="mb-2.5 block text-[0.9rem] text-muted transition-colors duration-300 hover:text-accent"
            >
              GitHub
            </a>
            <a
              href={SOCIAL.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="mb-2.5 block text-[0.9rem] text-muted transition-colors duration-300 hover:text-accent"
            >
              LinkedIn
            </a>
            <a
              href={SOCIAL.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="mb-2.5 block text-[0.9rem] text-muted transition-colors duration-300 hover:text-accent"
            >
              Instagram
            </a>
            <a
              href={`mailto:${SOCIAL.email}`}
              className="mb-2.5 block text-[0.9rem] text-muted transition-colors duration-300 hover:text-accent"
            >
              Email
            </a>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-line pt-6">
          <p className="text-[0.82rem] text-faint">
            © {new Date().getFullYear()} Amine Fellah. All rights reserved.
          </p>
          <p className="text-[0.82rem] tabular-nums text-faint">
            Local Time / {time} (GMT+1)
          </p>
        </div>
      </div>
    </footer>
  );
}
