import Reveal from "./Reveal";
import SectionHead from "./SectionHead";

const STACK = [
  {
    label: "Languages",
    items: ["JavaScript", "TypeScript", "Python"],
  },
  {
    label: "Frontend",
    items: ["React", "Vite", "Tailwind CSS", "Flutter"],
  },
  {
    label: "Backend & Data",
    items: ["Node.js", "Express", "Flask / FastAPI", "MongoDB"],
  },
  {
    label: "AI & Automation",
    items: ["OpenAI API", "LangChain", "RAG Pipelines", "Workflow Automation"],
  },
  {
    label: "Tooling",
    items: ["Git & GitHub", "REST APIs", "Vercel", "Docker (basics)"],
  },
];

const LIFE = ["♟️ Chess", "📸 Photography", "🎨 Art", "🥊 Kickboxing", "🏃 Running", "🏋️ Lifting"];

export default function Skills() {
  return (
    <section id="skills" className="py-[110px]">
      <div className="mx-auto w-full max-w-[1140px] px-6">
        <SectionHead eyebrow="Stack & Interests">
          The exact tools I <em className="text-accent not-italic italic">build</em> with.
        </SectionHead>

        <div className="mb-16 grid grid-cols-1 gap-x-10 gap-y-10 sm:grid-cols-2">
          {STACK.map((block, i) => (
            <Reveal key={block.label} delay={i * 70}>
              <h4 className="mb-5 text-[0.78rem] uppercase tracking-[0.16em] text-faint">
                {block.label}
              </h4>
              <div className="flex flex-wrap gap-3">
                {block.items.map((item) => (
                  <span
                    key={item}
                    className="rounded-full border border-line px-4.5 px-[18px] py-2.5 text-[0.88rem] text-text transition-all duration-300 hover:-translate-y-0.5 hover:border-accent hover:bg-accent-dim"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <h4 className="mb-5 text-[0.78rem] uppercase tracking-[0.16em] text-faint">
            Beyond Code
          </h4>
          <div className="flex flex-wrap gap-3">
            {LIFE.map((item) => (
              <span
                key={item}
                className="rounded-full border border-line px-[18px] py-2.5 text-[0.88rem] text-text transition-all duration-300 hover:-translate-y-0.5 hover:border-accent hover:bg-accent-dim"
              >
                {item}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
