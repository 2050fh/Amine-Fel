import Overline from "./Overline";

export default function Hero() {
  return (
    <section
      id="top"
      className="relative flex min-h-screen items-center overflow-hidden pb-16 pt-32"
    >
      <div className="pointer-events-none absolute inset-0 z-0">
        <div className="absolute -right-[10%] -top-[10%] h-[60vw] w-[60vw] max-h-[720px] max-w-[720px] rounded-full bg-[radial-gradient(circle,rgba(74,222,128,.16),transparent_62%)] blur-[30px]" />
        <div className="absolute -bottom-[15%] -left-[12%] h-[50vw] w-[50vw] max-h-[560px] max-w-[560px] rounded-full bg-[radial-gradient(circle,rgba(74,222,128,.07),transparent_65%)] blur-[30px]" />
      </div>

      <div className="relative z-[2] mx-auto w-full max-w-[1140px] px-6">
        <div className="mb-6">
          <Overline>Freelance · Based in Algeria</Overline>
        </div>
        <h1 className="mb-6 font-serif text-[clamp(2.6rem,9vw,6.2rem)] font-normal leading-[1.02] tracking-[-0.02em]">
          Amine <em className="text-accent not-italic italic">Fellah</em> builds
          <br className="hidden sm:block" /> production-grade
          <br className="hidden sm:block" /> software.
        </h1>
        <p className="mb-4 text-[clamp(1rem,3.4vw,1.35rem)] font-normal text-text">
          AI &amp; Full-Stack Developer
        </p>
        <p className="mb-10 max-w-[540px] text-[1.02rem] text-muted">
          Freelance developer designing and shipping intelligent, reliable
          products — AI-driven tools, web apps and automations built with a
          modern JavaScript, Python and cloud stack.
        </p>
        <div className="flex flex-wrap gap-4">
          <a
            href="#work"
            className="inline-flex items-center gap-2.5 rounded-full bg-accent px-6.5 px-[26px] py-[14px] text-[0.9rem] font-medium text-[#07110b] transition-transform duration-300 hover:-translate-y-[3px]"
          >
            View case studies
          </a>
          <a
            href="#contact"
            className="inline-flex items-center gap-2.5 rounded-full border border-line px-[26px] py-[14px] text-[0.9rem] text-text transition-all duration-300 hover:-translate-y-[3px] hover:border-accent hover:bg-accent-dim"
          >
            Start a project
          </a>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 z-[2] flex -translate-x-1/2 flex-col items-center gap-2.5 text-[0.68rem] uppercase tracking-[0.24em] text-faint">
        <span>Scroll</span>
        <span className="animate-cue h-[38px] w-px bg-gradient-to-b from-accent to-transparent" />
      </div>
    </section>
  );
}
