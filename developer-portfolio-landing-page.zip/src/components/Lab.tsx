import Reveal from "./Reveal";
import SectionHead from "./SectionHead";
import { IconArrowUpRight, IconGitHub } from "./icons";
import { LAB_PROJECTS } from "../data/labProjects";

export default function Lab() {
  return (
    <section id="lab" className="py-[110px]">
      <div className="mx-auto w-full max-w-[1140px] px-6">
        <SectionHead eyebrow="Personal Lab · Open Source">
          Since client work is under NDA — <em className="text-accent not-italic italic">here's the code.</em>
        </SectionHead>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {LAB_PROJECTS.map((p, i) => (
            <Reveal key={p.name} delay={i * 90}>
              <article className="flex h-full flex-col justify-between rounded-2xl border border-line bg-panel p-7 transition-all duration-400 hover:-translate-y-1.5 hover:border-accent/35">
                <div>
                  <h3 className="mb-1.5 font-serif text-[1.3rem]">{p.name}</h3>
                  <p className="mb-3 text-[0.82rem] uppercase tracking-wide text-faint">
                    {p.tagline}
                  </p>
                  <p className="mb-5 text-[0.88rem] text-muted">{p.desc}</p>
                  <div className="mb-6 flex flex-wrap gap-2">
                    {p.stack.map((s) => (
                      <span
                        key={s}
                        className="rounded-full border border-line px-2.5 py-1 text-[0.7rem] text-muted"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <a
                    href={p.repo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 rounded-full border border-line px-4 py-2 text-[0.82rem] transition-colors duration-300 hover:border-accent hover:bg-accent-dim"
                  >
                    <IconGitHub className="h-[14px] w-[14px]" /> Code
                  </a>
                  {p.demo && (
                    <a
                      href={p.demo}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-[0.82rem] text-accent transition-opacity hover:opacity-75"
                    >
                      Live demo <IconArrowUpRight className="h-[13px] w-[13px]" />
                    </a>
                  )}
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
