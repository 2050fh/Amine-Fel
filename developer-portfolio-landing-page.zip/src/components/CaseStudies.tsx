import Reveal from "./Reveal";
import SectionHead from "./SectionHead";
import { IconLock } from "./icons";
import { CASE_STUDIES } from "../data/caseStudies";

export default function CaseStudies() {
  return (
    <section id="work" className="py-[110px]">
      <div className="mx-auto w-full max-w-[1140px] px-6">
        <SectionHead eyebrow="Selected Work">
          Six freelance engagements, <em className="text-accent not-italic italic">anonymized.</em>
        </SectionHead>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {CASE_STUDIES.map((c, i) => (
            <Reveal key={c.title} delay={(i % 3) * 90}>
              <article className="group relative flex h-full min-h-[280px] flex-col justify-between overflow-hidden rounded-2xl border border-line bg-panel p-7 pb-6 transition-all duration-400 hover:-translate-y-1.5 hover:border-accent/35">
                <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_80%_-10%,var(--color-accent-dim),transparent_55%)] opacity-0 transition-opacity duration-450 group-hover:opacity-100" />

                <div className="relative flex items-start justify-between gap-3">
                  <span className="font-serif text-[1.05rem] text-faint">
                    0{i + 1}
                  </span>
                  <span className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border border-accent-dim px-2.5 py-1.5 text-[0.66rem] uppercase tracking-[0.1em] text-accent">
                    <IconLock className="h-[11px] w-[11px]" />
                    NDA · Anonymized
                  </span>
                </div>

                <div className="relative">
                  <p className="mb-2 text-[0.72rem] uppercase tracking-[0.1em] text-faint">
                    {c.sector}
                  </p>
                  <h3 className="mb-3 font-serif text-[1.35rem] font-normal leading-[1.15]">
                    {c.title}
                  </h3>
                  <p className="text-[0.88rem] text-muted">{c.result}</p>
                </div>

                <div className="relative mt-5 flex flex-wrap items-center gap-2">
                  {c.stack.map((s) => (
                    <span
                      key={s}
                      className="rounded-full border border-line px-2.5 py-1 text-[0.7rem] text-muted"
                    >
                      {s}
                    </span>
                  ))}
                </div>

                <div className="relative mt-4 flex items-center gap-2 text-[0.78rem] text-faint">
                  <span className="h-1.5 w-1.5 rounded-full bg-accent shadow-[0_0_0_4px_var(--color-accent-dim)]" />
                  {c.status}
                </div>
              </article>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-9 text-center text-[0.85rem] text-faint">
          Full case studies, metrics and screenshots are available on request,
          subject to client approval and NDA terms.
        </Reveal>
      </div>
    </section>
  );
}
