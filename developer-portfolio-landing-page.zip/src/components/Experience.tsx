import Reveal from "./Reveal";
import SectionHead from "./SectionHead";

const ROWS = [
  {
    yr: "Present",
    title: "Freelance AI & Web Developer",
    desc: "Designing and building AI-powered tools, automations and web applications for private clients — end to end, from architecture to deployment.",
    tag: "Independent",
  },
  {
    yr: "Present",
    title: "Student · Science & Technology",
    desc: "Chadli Bendjedid University of El Tarf — foundations in science and technology alongside self-driven software development and shipped client work.",
    tag: "University",
  },
];

export default function Experience() {
  return (
    <section id="experience" className="py-[110px]">
      <div className="mx-auto w-full max-w-[1140px] px-6">
        <SectionHead eyebrow="Experience">
          Freelance work, <em className="text-accent not-italic italic">built to spec.</em>
        </SectionHead>

        <div className="border-t border-line">
          {ROWS.map((r, i) => (
            <Reveal key={r.title} delay={i * 80}>
              <div className="grid grid-cols-1 items-baseline gap-2 border-b border-line px-1.5 py-7 transition-all duration-350 hover:bg-bg-soft hover:pl-5 sm:grid-cols-[120px_1fr_auto] sm:gap-7">
                <span className="text-[0.85rem] tracking-wide text-faint">
                  {r.yr}
                </span>
                <div>
                  <h3 className="mb-1.5 font-serif text-[1.3rem] font-normal">
                    {r.title}
                  </h3>
                  <p className="max-w-[520px] text-[0.92rem] text-muted">
                    {r.desc}
                  </p>
                </div>
                <span className="w-fit whitespace-nowrap rounded-full border border-accent-dim px-3 py-1.5 text-[0.72rem] uppercase tracking-[0.12em] text-accent">
                  {r.tag}
                </span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
