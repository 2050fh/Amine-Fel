import { useState, type FormEvent } from "react";
import Overline from "./Overline";
import Reveal from "./Reveal";
import { SOCIAL } from "../data/links";
import {
  IconGitHub,
  IconInstagram,
  IconLinkedIn,
  IconMail,
  IconPhone,
} from "./icons";

const PROJECT_TYPES = [
  "AI tool / automation",
  "Web application",
  "Website / landing page",
  "Mobile app (Flutter)",
  "Something else",
];

const BUDGETS = ["< $500", "$500 – $1,500", "$1,500 – $5,000", "$5,000+", "Not sure yet"];

const TIMELINES = ["ASAP", "Within 2 weeks", "Within a month", "Flexible / exploring"];

export default function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [projectType, setProjectType] = useState(PROJECT_TYPES[0]);
  const [budget, setBudget] = useState(BUDGETS[0]);
  const [timeline, setTimeline] = useState(TIMELINES[0]);
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

    const subject = `New project inquiry — ${projectType}`;
    const body = [
      `Name: ${name}`,
      `Email: ${email}`,
      `Project type: ${projectType}`,
      `Budget range: ${budget}`,
      `Timeline: ${timeline}`,
      "",
      "Project details:",
      message,
    ].join("\n");

    window.location.href = `mailto:${SOCIAL.email}?subject=${encodeURIComponent(
      subject
    )}&body=${encodeURIComponent(body)}`;

    setSent(true);
  };

  return (
    <section className="pb-16" id="contact">
      <div className="mx-auto w-full max-w-[1140px] px-6">
        <Reveal>
          <div className="relative overflow-hidden rounded-[22px] border border-line bg-gradient-to-b from-bg-soft to-bg p-[clamp(28px,6vw,64px)]">
            <div className="pointer-events-none absolute -right-[10%] -top-[40%] h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle,var(--color-accent-dim),transparent_60%)] blur-[20px]" />

            <div className="relative grid grid-cols-1 gap-12 lg:grid-cols-[1fr_1.15fr]">
              <div>
                <div className="mb-5">
                  <Overline>Contact</Overline>
                </div>
                <h2 className="mb-7 font-serif text-[clamp(2rem,6vw,3rem)] font-normal leading-[1.08] tracking-[-0.02em]">
                  Have a project?
                  <br />
                  Let's <em className="text-accent not-italic italic">scope</em> it.
                </h2>
                <p className="mb-8 max-w-md text-[0.95rem] text-muted">
                  Tell me a bit about what you need below, or reach out
                  directly — I usually reply within a day.
                </p>

                <div className="flex flex-wrap gap-3.5">
                  <a
                    className="inline-flex items-center gap-2.5 rounded-full border border-line px-5 py-3 text-[0.88rem] transition-all duration-300 hover:-translate-y-0.5 hover:border-accent hover:bg-accent-dim"
                    href={`mailto:${SOCIAL.email}`}
                  >
                    <IconMail className="h-4 w-4 text-accent" />
                    {SOCIAL.email}
                  </a>
                  <a
                    className="inline-flex items-center gap-2.5 rounded-full border border-line px-5 py-3 text-[0.88rem] transition-all duration-300 hover:-translate-y-0.5 hover:border-accent hover:bg-accent-dim"
                    href={SOCIAL.phoneHref}
                  >
                    <IconPhone className="h-4 w-4 text-accent" />
                    {SOCIAL.phone}
                  </a>
                  <a
                    className="inline-flex items-center gap-2.5 rounded-full border border-line px-5 py-3 text-[0.88rem] transition-all duration-300 hover:-translate-y-0.5 hover:border-accent hover:bg-accent-dim"
                    href={SOCIAL.github}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <IconGitHub className="h-4 w-4 text-accent" />
                    GitHub
                  </a>
                  <a
                    className="inline-flex items-center gap-2.5 rounded-full border border-line px-5 py-3 text-[0.88rem] transition-all duration-300 hover:-translate-y-0.5 hover:border-accent hover:bg-accent-dim"
                    href={SOCIAL.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <IconLinkedIn className="h-4 w-4 text-accent" />
                    LinkedIn
                  </a>
                  <a
                    className="inline-flex items-center gap-2.5 rounded-full border border-line px-5 py-3 text-[0.88rem] transition-all duration-300 hover:-translate-y-0.5 hover:border-accent hover:bg-accent-dim"
                    href={SOCIAL.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <IconInstagram className="h-4 w-4 text-accent" />
                    @2050_fh
                  </a>
                </div>
              </div>

              <form
                onSubmit={handleSubmit}
                className="relative rounded-2xl border border-line bg-bg/60 p-6 sm:p-8"
              >
                <div className="mb-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-[0.75rem] uppercase tracking-wide text-faint">
                      Name
                    </label>
                    <input
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      type="text"
                      placeholder="Your name"
                      className="w-full rounded-lg border border-line bg-transparent px-3.5 py-2.5 text-sm text-text outline-none transition-colors focus:border-accent"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-[0.75rem] uppercase tracking-wide text-faint">
                      Email
                    </label>
                    <input
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      type="email"
                      placeholder="you@company.com"
                      className="w-full rounded-lg border border-line bg-transparent px-3.5 py-2.5 text-sm text-text outline-none transition-colors focus:border-accent"
                    />
                  </div>
                </div>

                <div className="mb-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label className="mb-1.5 block text-[0.75rem] uppercase tracking-wide text-faint">
                      Project type
                    </label>
                    <select
                      value={projectType}
                      onChange={(e) => setProjectType(e.target.value)}
                      className="w-full rounded-lg border border-line bg-bg-soft px-3.5 py-2.5 text-sm text-text outline-none transition-colors focus:border-accent"
                    >
                      {PROJECT_TYPES.map((t) => (
                        <option key={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1.5 block text-[0.75rem] uppercase tracking-wide text-faint">
                      Budget
                    </label>
                    <select
                      value={budget}
                      onChange={(e) => setBudget(e.target.value)}
                      className="w-full rounded-lg border border-line bg-bg-soft px-3.5 py-2.5 text-sm text-text outline-none transition-colors focus:border-accent"
                    >
                      {BUDGETS.map((b) => (
                        <option key={b}>{b}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1.5 block text-[0.75rem] uppercase tracking-wide text-faint">
                      Timeline
                    </label>
                    <select
                      value={timeline}
                      onChange={(e) => setTimeline(e.target.value)}
                      className="w-full rounded-lg border border-line bg-bg-soft px-3.5 py-2.5 text-sm text-text outline-none transition-colors focus:border-accent"
                    >
                      {TIMELINES.map((t) => (
                        <option key={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="mb-5">
                  <label className="mb-1.5 block text-[0.75rem] uppercase tracking-wide text-faint">
                    Project details
                  </label>
                  <textarea
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    rows={4}
                    placeholder="What are you trying to build?"
                    className="w-full resize-none rounded-lg border border-line bg-transparent px-3.5 py-2.5 text-sm text-text outline-none transition-colors focus:border-accent"
                  />
                </div>

                <button
                  type="submit"
                  className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-accent px-6 py-3.5 text-[0.9rem] font-medium text-[#07110b] transition-transform duration-300 hover:-translate-y-0.5 sm:w-auto"
                >
                  Send project brief
                </button>

                {sent && (
                  <p className="mt-4 text-[0.85rem] text-accent">
                    Your email client should now be open with the brief
                    pre-filled — hit send and I'll get back to you within a
                    day.
                  </p>
                )}
              </form>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
