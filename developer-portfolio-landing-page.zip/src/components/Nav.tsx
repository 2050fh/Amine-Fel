import { useEffect, useState } from "react";
import { IconGitHub, IconLinkedIn } from "./icons";
import { SOCIAL } from "../data/links";

const LINKS = [
  { href: "#about", label: "About" },
  { href: "#experience", label: "Experience" },
  { href: "#work", label: "Case Studies" },
  { href: "#lab", label: "Lab" },
  { href: "#skills", label: "Stack" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const close = () => setOpen(false);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-[60] border-b transition-all duration-400 ${
        scrolled
          ? "border-line bg-bg/85 py-3 backdrop-blur-md"
          : "border-transparent py-[18px]"
      }`}
    >
      <div className="mx-auto flex w-full max-w-[1140px] items-center justify-between px-6">
        <a href="#top" className="font-serif text-[1.15rem] font-medium tracking-tight">
          Amine<span className="text-accent">.</span>
        </a>

        <nav
          className={`fixed inset-y-0 right-0 z-[70] flex w-[min(78vw,320px)] flex-col items-start justify-center gap-6 border-l border-line bg-bg-soft p-10 transition-transform duration-450 ease-[cubic-bezier(.22,.61,.36,1)] sm:static sm:z-auto sm:w-auto sm:flex-row sm:items-center sm:gap-9 sm:border-0 sm:bg-transparent sm:p-0 sm:translate-x-0 ${
            open ? "translate-x-0" : "translate-x-full sm:translate-x-0"
          }`}
        >
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={close}
              className="group relative text-[1.05rem] text-muted transition-colors duration-300 hover:text-text sm:text-[0.85rem] sm:tracking-wide"
            >
              {l.label}
              <span className="absolute -bottom-[5px] left-0 h-px w-0 bg-accent transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
          <div className="flex items-center gap-4 pt-2 sm:pt-0">
            <a
              href={SOCIAL.github}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
              className="text-muted transition-colors hover:text-accent"
            >
              <IconGitHub className="h-[18px] w-[18px]" />
            </a>
            <a
              href={SOCIAL.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
              className="text-muted transition-colors hover:text-accent"
            >
              <IconLinkedIn className="h-[18px] w-[18px]" />
            </a>
          </div>
          <a
            href="#contact"
            onClick={close}
            className="rounded-full border border-line px-[18px] py-[9px] text-[0.82rem] text-text transition-colors duration-300 hover:border-accent hover:bg-accent-dim"
          >
            Start a project
          </a>
        </nav>

        <button
          aria-label="Menu"
          onClick={() => setOpen((o) => !o)}
          className="z-[80] flex flex-col gap-[5px] p-1.5 sm:hidden"
        >
          <span
            className={`h-[1.5px] w-6 bg-text transition-transform duration-300 ${
              open ? "translate-y-[6.5px] rotate-45" : ""
            }`}
          />
          <span className={`h-[1.5px] w-6 bg-text transition-opacity duration-300 ${open ? "opacity-0" : ""}`} />
          <span
            className={`h-[1.5px] w-6 bg-text transition-transform duration-300 ${
              open ? "-translate-y-[6.5px] -rotate-45" : ""
            }`}
          />
        </button>
      </div>
    </header>
  );
}
