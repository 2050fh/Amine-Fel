import Overline from "./Overline";
import Reveal from "./Reveal";

export default function SectionHead({
  eyebrow,
  children,
  className = "",
}: {
  eyebrow: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <Reveal className={`mb-14 max-w-[720px] ${className}`}>
      <div className="mb-5">
        <Overline>{eyebrow}</Overline>
      </div>
      <h2 className="font-serif text-[clamp(1.9rem,5vw,3.1rem)] font-normal leading-[1.1] tracking-[-0.015em]">
        {children}
      </h2>
    </Reveal>
  );
}
